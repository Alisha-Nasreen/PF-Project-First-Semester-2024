#include <iostream>
#include <vector>
#include <string>
#include <windows.h>
#include <limits>  

using namespace std;

void setColor(int color) {
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), color);
}

void clearScreen() {
    #ifdef _WIN32
        system("cls"); 
    #else
        system("clear");
    #endif
}

struct Bus {
    string busID;
    string driverName;
    string destination;
    int totalSeats;
    int bookedSeats = 0;
};


vector<Bus> buses;  


const double SEAT_PRICE = 100.0;  


void addBus();  // Function prototypes
void viewBuses();
void updateBus();
void deleteBus();
void bookSeats();
bool processPayment(double amount);
void updateSeatInfo();
void deleteSeat();
void viewAvailableBuses();
void viewAvailableSeats();
void busManagementMenu();
void passengerManagementMenu();
void mainMenu();
bool login();




bool login() { 
    string username, password;
    string correctUsername = "Bus2024";  
    string correctPassword = "admin";   
    int attempts = 0; 

    setColor(6); 
    clearScreen();
    cout << "\t******************************************************************************************************\n";
    cout << "\n\t\t\t\t*** Bus Reservation System Project 2024 ***\n\n";
    cout << "\n\t\t\t\t*** Made by Alisha NAsreen & Iram Ghafoor ***\n\n"; 
    cout << "\t******************************************************************************************************\n";
    setColor(7);
    
    while (attempts < 3) {
        setColor(9); 
        cout << "\n\nEnter Username: ";
        cin >> username;
        cout << "Enter Password: ";
        cin >> password;

        if (username == correctUsername && password == correctPassword) {
            setColor(2);
            cout << "\nLogin successful!  " << "\n";
            system("pause");
            clearScreen();
            return true;
        } else {
            setColor(4);
            cout << "\nInvalid username or password!\n";
            setColor(6);
            cout << "Please try again.\n";
            attempts++;
            system("pause");
            clearScreen();
        }
    }
    setColor(6);
    cout << "Maximum login attempts reached. Exiting...\n";
    clearScreen();
    return false;
}


void addBus() { 
    Bus newBus;
    setColor(1);
    cout << "\nEnter Bus ID: ";
    cin >> newBus.busID;
    cout << "Enter Driver's Name: ";
    cin.ignore(); 
    getline(cin, newBus.driverName);
    cout << "Enter Destination: ";
    getline(cin, newBus.destination);
    cout << "Enter Total Seats: ";
    cin >> newBus.totalSeats;
    
    buses.push_back(newBus);  
    setColor(2);  
    cout << "Bus added successfully!\n";
    system("pause");  
    clearScreen();  
}



void viewBuses() {
    if (buses.empty()) {
    	setColor(6);
        cout << "\nNo buses available.\n";
        system("pause");  
        clearScreen();  
        return;
    }
    cout << "\nList of Buses:\n";
    cout << "-------------------------------------------------------------\n";
    cout << "Bus ID\t\tDriver Name\t\tDestination\t\tSeats Available\n";
    cout << "-------------------------------------------------------------\n";
    for (const auto &bus : buses) {
        cout << bus.busID << "\t\t" << bus.driverName << "\t\t\t"
             << bus.destination << "\t\t\t"
             << (bus.totalSeats - bus.bookedSeats) << "/" << bus.totalSeats << "\n";
    }
    system("pause");  
    clearScreen();  
}

void updateBus() {
    string busID;
    	setColor(7);
    cout << "\nEnter Bus ID to update: ";
    cin >> busID;

    for (auto &bus : buses) {
        if (bus.busID == busID) {
            int updateChoice;
            setColor(3);
            cout << "Which field would you like to update?\n";
            setColor(6); 
            cout << "\n1. Driver's Name\n";
            cout << "2. Destination\n";
            cout << "3. Total Seats\n";
            setColor(3);
            cout << "\nEnter a number for your choice: ";
            
            while (!(cin >> updateChoice)) {
                cin.clear(); 
                cin.ignore(numeric_limits<streamsize>::max(), '\n');
              	setColor(4);
                cout << "\nInvalid input. Enter a valid number for your choice: ";
            }

            switch (updateChoice) {
                case 1:
                		setColor(6);
                    cout << "Enter new Driver's Name: ";
                    cin.ignore();  
                    getline(cin, bus.driverName);
                    setColor(2);
                    cout << "Driver's Name updated successfully!\n";
                    break;
                case 2:
                    cout << "Enter new Destination: ";
                    cin.ignore();
                    getline(cin, bus.destination);
                    	setColor(2);
                    cout << "\nDestination updated successfully!\n";
                    break;
                case 3:
                		setColor(5);
                    cout << "Enter new Total Seats: ";
                    cin >> bus.totalSeats;
                    setColor(2);
                    cout << "\nTotal Seats updated successfully!\n";
                    break;
                default:
                		setColor(6);
                    cout << "\nInvalid choice.\n";
                    break;
            }
            system("pause");  
            clearScreen();  
            return;
        }
    }
setColor(6);
    cout << "Bus with ID " << busID << " not found.\n";
    clearScreen(); 
}

void deleteBus() {
    string busID;
    cout << "\nEnter Bus ID to delete: ";
    cin >> busID;
    for (auto it = buses.begin(); it != buses.end(); ++it) {
        if (it->busID == busID) {
            buses.erase(it);
            setColor(2);
            cout << "\nBus deleted successfully!\n";
            system("pause");
            return;
        }
    }setColor(6);
    cout << "Bus with ID " << busID << " not found.\n";
    system("pause");  
    clearScreen();  
}

bool processPayment(double amount) {
    double payment;
    cout << "Total amount to pay: " << amount << "\n";
    cout << "\nEnter payment amount: ";
    while (!(cin >> payment)) {
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
        setColor(6);
        cout << "\nInvalid input. Enter a valid number: ";
    }

    if (payment < amount) {
    		setColor(4);
        cout << "Insufficient payment. Please enter a valid amount.\n";
        return false; 
    } else {
        double change = payment - amount;
        cout << "\nPayment successful! Your change: " << change << "\n";
        cout<<"Thank you for Visiting our App ";
        return true; 
    }
}
void viewAvailableBuses() {
    bool availableBusesFound = false;
    setColor(7);
    cout << "\nAvailable Buses for Booking:\n";
    cout << "-------------------------------------------------------------\n";
    cout << "Bus ID\t\tDriver Name\t\tDestination\t\tSeats Available\n";
    cout << "-------------------------------------------------------------\n";
    
    for (const auto &bus : buses) {
        if (bus.totalSeats > bus.bookedSeats) {
            cout << bus.busID << "\t\t" << bus.driverName << "\t\t\t"
                 << bus.destination << "\t\t\t"
                 << (bus.totalSeats - bus.bookedSeats) << "/" << bus.totalSeats << "\n";
            availableBusesFound = true;
        }
    }

    if (!availableBusesFound) {
        setColor(6);
        cout << "No available buses for booking.\n";
    }
    system("pause");
    clearScreen();
}

void bookSeats() {
    string busID;
    int seatsToBook;
    cout << "Enter Bus ID to book seats: ";
    cin >> busID;
    for (auto &bus : buses) {
        if (bus.busID == busID) {
            cout << "Enter number of seats to book: ";
            while (!(cin >> seatsToBook) || seatsToBook <= 0 || seatsToBook > (bus.totalSeats - bus.bookedSeats)) {
                cin.clear();
                cin.ignore(numeric_limits<streamsize>::max(), '\n');
                setColor(6);
                cout << "Invalid number of seats. Please enter a valid number (1 to " 
                     << (bus.totalSeats - bus.bookedSeats) << "): ";
            }

            double totalAmount = seatsToBook * SEAT_PRICE;
            if (processPayment(totalAmount)) {
                bus.bookedSeats += seatsToBook;
                setColor(2);
                cout << seatsToBook << " seats booked successfully! Seats left: "
                     << (bus.totalSeats - bus.bookedSeats) << "\n";
            } else {
                cout << "\nSeat booking failed due to insufficient payment.\n";
            }
            system("pause");
            clearScreen();
            return;
        }
    }
    setColor(6);
    cout << "Bus with ID " << busID << " not found.\n";
    clearScreen();
}
void viewAvailableSeats() {
    string busID;
    setColor(7);
    cout << "Enter Bus ID to view available seats: ";
    cin >> busID;
    for (const auto &bus : buses) {
        if (bus.busID == busID) {
            setColor(6);
            cout << "Available seats for Bus ID " << bus.busID << ": "
                 << (bus.totalSeats - bus.bookedSeats) << "/" << bus.totalSeats << "\n";
            system("pause");
            clearScreen();
            return;
        }
    }
    cout << "Bus with ID " << busID << " not found.\n";
    clearScreen();
}

void updateSeatInfo() {
    string busID;
    setColor(7);
    cout << "Enter Bus ID to update seat info: ";
    cin >> busID;

    for (auto &bus : buses) {
        if (bus.busID == busID) {
            int updateChoice;
            cout << "Which seat info would you like to update?\n";
            cout << "\n1. Booked Seats\n";
            cout << "2. Total Seats\n";
            setColor(5);
            cout << "\nEnter a number for your choice: ";
            
     
            while (true) {
                if (!(cin >> updateChoice)) {
                    cin.clear();  
                    cin.ignore(numeric_limits<streamsize>::max(), '\n'); 
                    setColor(6);
                    cout << "Invalid input. Please enter a valid number for your choice: ";
                } else if (updateChoice < 1 || updateChoice > 2) {
                    setColor(6);
                    cout << "Invalid choice. Please enter 1 or 2.\n";
                } else {
                    break;  
                }
            }

            switch (updateChoice) {
                case 1:
                    cout << "Enter new number of Booked Seats: ";
                    while (true) {
                        if (!(cin >> bus.bookedSeats) || bus.bookedSeats < 0) {
                            cin.clear();
                            cin.ignore(numeric_limits<streamsize>::max(), '\n');
                            setColor(6);
                            cout << "Invalid input. Please enter a valid number of booked seats (>= 0): ";
                        } else if (bus.bookedSeats > bus.totalSeats) {
                            setColor(6);
                            cout << "Error! Booked seats cannot be greater than total seats.\n";
                            cout << "Setting booked seats to total seats.\n";
                            bus.bookedSeats = bus.totalSeats;
                            break;
                        } else {
                            break;
                        }
                    }
                    setColor(2);
                    cout << "Booked seats updated successfully!\n";
                    break;
                case 2:
                    cout << "Enter new Total Seats: ";
                    while (true) {
                        if (!(cin >> bus.totalSeats) || bus.totalSeats < 0) {
                            cin.clear();
                            cin.ignore(numeric_limits<streamsize>::max(), '\n');
                            setColor(6);
                            cout << "Invalid input. Please enter a valid number of total seats (>= 0): ";
                        } else if (bus.totalSeats < bus.bookedSeats) {
                            setColor(6);
                            cout << "Error! Total seats cannot be less than booked seats.\n";
                            cout << "Setting total seats to booked seats.\n";
                            bus.totalSeats = bus.bookedSeats;
                            break;
                        } else {
                            break;
                        }
                    }
                    setColor(2);
                    cout << "Total seats updated successfully!\n";
                    break;
                default:
                    setColor(6);
                    cout << "Invalid choice.\n";
                    break;
            }
            system("pause");
            clearScreen();
            return;
        }
    }

    setColor(6);
    cout << "Bus with ID " << busID << " not found.\n";
    system("pause");
    clearScreen();
}

void deleteSeat() {
    string busID;
    int seatsToDelete;
    setColor(6);
    cout << "Enter Bus ID to delete seats: ";
    cin >> busID;
    for (auto &bus : buses) {
        if (bus.busID == busID) {
            cout << "Enter number of seats to delete: ";
            while (!(cin >> seatsToDelete) || seatsToDelete <= 0 || seatsToDelete > bus.bookedSeats) {
                cin.clear(); 
                cin.ignore(numeric_limits<streamsize>::max(), '\n');
                setColor(1);
                cout << "Invalid number of seats. Please enter a valid number (1 to " 
                     << bus.bookedSeats << "): ";
            }

            bus.bookedSeats -= seatsToDelete;
            setColor(5);
            cout << seatsToDelete << " seats deleted successfully!\n";
            system("pause");
            clearScreen();
            return;
        }
    }
    cout << "Bus with ID " << busID << " not found.\n";
    clearScreen();
}
void passengerManagementMenu() {
    int choice;
    do {
        
        setColor(5);
        cout << "\n\t\t\t\t\t*** Passenger Management Menu ***\n";
        setColor(3);
        cout << "\n1. Book Seats\n";
        cout << "2. View Available Seats\n";
        cout << "3. Update Seat Information\n";
        cout << "4. Delete Seats\n";
        cout << "5. View Available Buses\n";  
        cout << "6. Go Back to Main Menu\n";
         setColor(6);
        cout << "\nEnter your choice: ";
        
        while (!(cin >> choice)) {
            cin.clear(); 
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            setColor(1);
            cout << "\nInvalid input. Enter a valid number for your choice: ";
        }
        switch (choice) {
            case 1: bookSeats(); break;
            case 2: viewAvailableSeats(); break;
            case 3: updateSeatInfo(); break;
            case 4: deleteSeat(); break;
            case 5: viewAvailableBuses(); break; 
            case 6: return;  
            default: 
                cout << "\nInvalid choice. Please try again.\n"; 
                break;
        }
    } while (true);
    clearScreen();
}

void busManagementMenu() {
    int choice;
    do {
        clearScreen();
        setColor(6);
        cout << "\n\t\t\t*****Bus Management Menu*****\n";
        setColor(7);
        cout << "\n1. Add Bus\n";
        cout << "2. View Buses\n";
        cout << "3. Update Bus Info\n";
        cout << "4. Delete Bus\n";
        cout << "5. Exit to Main Menu\n";
        setColor(5); 
        cout << "\nEnter your choice: ";
        
        while (!(cin >> choice)) {
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            setColor(6);
            cout << "\nInvalid input. Please enter a valid option: ";
        }

        switch (choice) {
            case 1: addBus(); break;
            case 2: viewBuses(); break;
            case 3: updateBus(); break;
            case 4: deleteBus(); break;
            case 5: break;
            default:
            	setColor(6);
                cout << "\nInvalid option, please try again.\n";
                break;
        }
    } while (choice != 5);
}

void mainMenu() {
    int choice;
    do {
        clearScreen();
        setColor(6);
        cout<<"\n\t\t\t\t*********WELCOME TO PUNJAB TRANSPORT**********";
        cout << "\n\n\t\t\t\t\t --- Main Menu ---\n";
        setColor(7);
        cout << "\n1. Bus Management\n";
        cout << "2. Passenger Management\n";
        cout << "3. Exit\n";
        setColor(5); 
        cout << "\nEnter your choice: ";
        
        while (!(cin >> choice)) {
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            setColor(1);
            cout << "\nInvalid input. Please enter a valid option: ";
        }

        switch (choice) {
            case 1: busManagementMenu(); break;
            case 2: passengerManagementMenu(); break;
            case 3: break;
            default:
            	setColor(6);
                cout << "\nInvalid option, please try again.\n";
                break;
        }
    } while (choice != 3);
}

int main() {
    if (login()) {
        mainMenu();
    }
    return 0;
}
